"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var MainModuleLibrary_1 = require('../Binder/MainModuleLibrary');
var platform = platform_browser_dynamic_1.platformBrowserDynamic();
platform.bootstrapModule(MainModuleLibrary_1.MainModuleLibrary);
//# sourceMappingURL=Startup.js.map