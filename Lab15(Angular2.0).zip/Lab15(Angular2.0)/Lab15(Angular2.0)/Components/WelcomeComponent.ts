﻿import {Component} from "@angular/core"

@Component({
    template : "Welcome to Customer & Supplier management system"
})
export class WelcomeComponent {
    
}