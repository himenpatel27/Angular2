﻿import {Component} from "@angular/core"

@Component({
    templateUrl : "../UI/Supplier.html"
})
export class SupplierComponent {
    
}