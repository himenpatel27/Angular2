﻿import {Component} from "@angular/core"

@Component({
    templateUrl : "../UI/Help.html"
})
export class HelpComponent {
    
}