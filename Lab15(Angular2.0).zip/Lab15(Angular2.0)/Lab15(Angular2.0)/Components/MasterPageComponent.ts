﻿import {Component} from "@angular/core"

@Component({
    selector: "customer-ui",
    templateUrl: "../UI/MasterPage.html"
})
export class MasterPageComponent {

}