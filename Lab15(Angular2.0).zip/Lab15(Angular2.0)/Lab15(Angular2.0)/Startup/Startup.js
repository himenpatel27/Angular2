"use strict";
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var MainModule_1 = require("../Modules/MainModule");
var platform = platform_browser_dynamic_1.platformBrowserDynamic();
platform.bootstrapModule(MainModule_1.MainModule);
//# sourceMappingURL=Startup.js.map