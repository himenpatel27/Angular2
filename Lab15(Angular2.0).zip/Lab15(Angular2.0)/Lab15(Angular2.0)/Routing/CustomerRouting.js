"use strict";
var CustomerComponent_1 = require("../Components/CustomerComponent");
exports.CustomerRoutes = [
    { path: 'Add', component: CustomerComponent_1.CustomerComponent }
];
//# sourceMappingURL=CustomerRouting.js.map