"use strict";
var WelcomeComponent_1 = require("../Components/WelcomeComponent");
var HelpComponent_1 = require("../Components/HelpComponent");
exports.MainRoutes = [
    { path: '', component: WelcomeComponent_1.WelcomeComponent },
    { path: 'UI/MasterAngular.html', component: WelcomeComponent_1.WelcomeComponent },
    { path: 'Customer', loadChildren: '/Modules/CustomerModule#CustomerModule' },
    { path: 'Supplier', loadChildren: '/Modules/SupplierModule#SupplierModule' },
    { path: 'Help', component: HelpComponent_1.HelpComponent, outlet: "helpoutlet" }
];
//# sourceMappingURL=MainRouting.js.map