﻿import {Component} from '@angular/core';
import {SupplierComponent} from "../Components/SupplierComponent";

export const SupplierRoutes = [
    { path: 'Add', component: SupplierComponent }
];
