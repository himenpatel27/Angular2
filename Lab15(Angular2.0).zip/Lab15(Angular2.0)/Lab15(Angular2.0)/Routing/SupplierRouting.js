"use strict";
var SupplierComponent_1 = require("../Components/SupplierComponent");
exports.SupplierRoutes = [
    { path: 'Add', component: SupplierComponent_1.SupplierComponent }
];
//# sourceMappingURL=SupplierRouting.js.map