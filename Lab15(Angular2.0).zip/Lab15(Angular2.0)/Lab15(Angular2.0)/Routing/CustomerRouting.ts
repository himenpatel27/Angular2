﻿import {Component} from '@angular/core';
import {CustomerComponent} from '../Components/CustomerComponent';


export const CustomerRoutes = [
    { path: 'Add', component: CustomerComponent }
];
